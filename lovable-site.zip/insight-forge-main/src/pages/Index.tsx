import { Link } from "react-router-dom";
import { ArrowRight, FileText } from "lucide-react";
import SiteLayout from "@/components/SiteLayout";
import FadeIn from "@/components/FadeIn";

const Index = () => (
  <SiteLayout>
    {/* Hero */}
    <section className="pt-20 pb-16 md:pt-32 md:pb-24">
      <div className="prose-container">
        <FadeIn>
          <p className="text-sm font-body font-semibold uppercase tracking-widest text-primary mb-4">
            Independent Research Organization
          </p>
          <h1 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold leading-tight tracking-tight text-foreground">
            Building the infrastructure that makes good decisions easier than bad ones.
          </h1>
          <p className="mt-6 text-lg md:text-xl text-muted-foreground leading-relaxed max-w-2xl">
            Multi-valence frameworks for ethical governance, AI safety, and human thriving — grounded in formal specification, not aspiration.
          </p>
        </FadeIn>
      </div>
    </section>

    {/* Ebook CTA */}
    <section className="pb-16 md:pb-24">
      <div className="prose-container">
        <FadeIn delay={0.1}>
          <div className="border-l-4 border-primary bg-accent-glow rounded-r-lg p-8 md:p-10">
            <div className="flex items-start gap-4">
              <FileText className="w-8 h-8 text-primary shrink-0 mt-1" />
              <div>
                <h2 className="font-display text-2xl font-bold text-foreground mb-2">
                  FREE ENERGY!
                </h2>
                <p className="text-muted-foreground leading-relaxed mb-5">
                  A 10-minute proof that cooperation produces surplus — not as a moral claim, but as a physical one. The Shoe Test: a framework you can apply before your next decision.
                </p>
                <a
                  href="#"
                  className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-5 py-2.5 rounded font-body font-semibold text-sm hover:opacity-90 transition-opacity"
                >
                  Download Free Ebook
                  <ArrowRight size={16} />
                </a>
              </div>
            </div>
          </div>
        </FadeIn>
      </div>
    </section>

    {/* What is Zx3 */}
    <section className="pb-16 md:pb-24">
      <div className="prose-container">
        <FadeIn delay={0.15}>
          <h2 className="font-display text-2xl md:text-3xl font-bold text-foreground mb-6">
            What is Zx3?
          </h2>
          <div className="space-y-4 text-muted-foreground leading-relaxed text-lg">
            <p>
              Most frameworks for governance, ethics, or AI safety optimize along a single axis: maximize benefit, minimize harm, ensure fairness. Zx3 starts from a different premise — that any system involving humans must hold <em>three valences</em> simultaneously: the capacity for harm ([-1]), genuine uncertainty ([0]), and concrete positive outcomes ([+1]).
            </p>
            <p>
              The framework maps these valences across three perspectives — Self, Other, and System — and applies them to Governance, Economy, and Culture. The result is a structured grid that reveals blind spots in any proposal, policy, or product.
            </p>
            <p>
              It's not a philosophy. It's measurement infrastructure.{" "}
              <Link
                to="/framework"
                className="text-primary font-semibold hover:underline underline-offset-4 transition-colors"
              >
                Read the full framework →
              </Link>
            </p>
          </div>
        </FadeIn>
      </div>
    </section>

    {/* Latest / Signal */}
    <section className="pb-16 md:pb-24">
      <div className="prose-container">
        <FadeIn delay={0.2}>
          <h2 className="font-display text-2xl md:text-3xl font-bold text-foreground mb-6">
            Latest
          </h2>
          <div className="space-y-6">
            {[
              {
                title: "Zx3 Core Specification v1.0",
                date: "2025-11-25",
                desc: "The minimal invariant specification for the multi-valence framework.",
                link: "/research",
              },
              {
                title: "PC-Ext v0.2 — Free Energy Correction",
                date: "2026-01",
                desc: "Formal correction extending predictive coding to account for cooperative surplus.",
                link: "/research",
              },
            ].map((item) => (
              <Link
                key={item.title}
                to={item.link}
                className="block group border border-border rounded-lg p-6 hover:border-primary/40 transition-colors"
              >
                <p className="text-xs font-mono text-muted-foreground mb-1">{item.date}</p>
                <h3 className="font-display text-lg font-semibold text-foreground group-hover:text-primary transition-colors">
                  {item.title}
                </h3>
                <p className="text-sm text-muted-foreground mt-1">{item.desc}</p>
              </Link>
            ))}
          </div>
        </FadeIn>
      </div>
    </section>
  </SiteLayout>
);

export default Index;
