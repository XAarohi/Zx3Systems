import { Mail, Github } from "lucide-react";
import SiteLayout from "@/components/SiteLayout";
import FadeIn from "@/components/FadeIn";

const About = () => (
  <SiteLayout>
    <article className="pt-16 pb-20 md:pt-24 md:pb-32">
      <div className="prose-container">
        <FadeIn>
          <p className="text-sm font-body font-semibold uppercase tracking-widest text-primary mb-3">About</p>
          <h1 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold leading-tight text-foreground mb-8">
            Xssandra Aarohi & Zx3 Systems
          </h1>
        </FadeIn>

        <FadeIn delay={0.1}>
          <div className="space-y-5 text-lg text-muted-foreground leading-relaxed mb-12">
            <p>
              Zx3 Systems is an independent research organization developing interconnected frameworks spanning AI safety, consciousness theory, ethical governance, and measurement formalization.
            </p>
            <p>
              The work begins from a simple observation: most systems that govern human interaction — economic, political, cultural — were not designed. They emerged. And the tools we've built to evaluate them tend to optimize along a single axis, making them effective at solving the wrong problems.
            </p>
            <p>
              Zx3 is an attempt to build better measurement infrastructure. Frameworks that hold harm, uncertainty, and benefit simultaneously. Tools that make ethical decisions structurally easier — not by preaching, but by making the costs visible.
            </p>
          </div>
        </FadeIn>

        <FadeIn delay={0.15}>
          <h2 className="font-display text-2xl font-bold text-foreground mb-4">
            The Researcher
          </h2>
          <div className="space-y-4 text-lg text-muted-foreground leading-relaxed mb-12">
            <p>
              Xssandra Aarohi is an independent researcher working across AI safety, consciousness theory, and ethical governance. The research synthesizes formal specification methods with accessible frameworks designed for real-world application.
            </p>
            <p>
              The work operates under significant resource constraints — primarily from mobile devices, without institutional affiliation. This is deliberate. The frameworks are designed to be useful without requiring permission, funding, or existing power structures to implement.
            </p>
          </div>
        </FadeIn>

        <FadeIn delay={0.2}>
          <h2 className="font-display text-2xl font-bold text-foreground mb-4">
            Roadmap
          </h2>
          <div className="space-y-4 text-lg text-muted-foreground leading-relaxed mb-12">
            <p>
              The current arc of work moves through four layers: foundational frameworks (Zx3 specification), accessible publications ("FREE ENERGY!", "The Fire and The Moss"), practitioner tools (assessment instruments), and formal research papers (Harm Inversion Theory, consciousness theory extensions).
            </p>
            <p>
              Each piece ships when it's ready. The site grows with the work — no empty sections, no coming-soon pages that never arrive.
            </p>
          </div>
        </FadeIn>

        <FadeIn delay={0.25}>
          <h2 className="font-display text-2xl font-bold text-foreground mb-6">Contact</h2>
          <div className="space-y-4">
            <a
              href="mailto:XssandraAarohi@proton.me"
              className="flex items-center gap-3 text-foreground hover:text-primary transition-colors group"
            >
              <Mail size={20} className="text-muted-foreground group-hover:text-primary transition-colors" />
              <span className="font-body font-semibold">XssandraAarohi@proton.me</span>
            </a>
            <a
              href="https://github.com"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-3 text-foreground hover:text-primary transition-colors group"
            >
              <Github size={20} className="text-muted-foreground group-hover:text-primary transition-colors" />
              <span className="font-body font-semibold">GitHub</span>
            </a>
          </div>
        </FadeIn>
      </div>
    </article>
  </SiteLayout>
);

export default About;
