import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import SiteLayout from "@/components/SiteLayout";
import FadeIn from "@/components/FadeIn";

const Framework = () => (
  <SiteLayout>
    <article className="pt-16 pb-20 md:pt-24 md:pb-32">
      <div className="prose-container">
        <FadeIn>
          <p className="text-sm font-body font-semibold uppercase tracking-widest text-primary mb-3">Framework</p>
          <h1 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold leading-tight text-foreground mb-8">
            The Zx3 Multi-Valence Framework
          </h1>
        </FadeIn>

        <FadeIn delay={0.1}>
          <div className="space-y-5 text-lg text-muted-foreground leading-relaxed">
            <p>
              Zx3 is a measurement framework for evaluating decisions, policies, and systems across three irreducible perspectives and three valences of outcome.
            </p>
            <p>
              The core insight: any proposal that only models positive outcomes is incomplete. Any framework that treats uncertainty as a problem to eliminate — rather than information to preserve — will produce fragile systems. And any analysis that ignores the perspective of those who bear the costs is, by construction, an instrument of harm.
            </p>
          </div>
        </FadeIn>

        {/* The Grid */}
        <FadeIn delay={0.15}>
          <div className="my-12 md:my-16">
            <h2 className="font-display text-2xl font-bold text-foreground mb-6">
              The Structure
            </h2>
            <p className="text-muted-foreground mb-8 text-lg leading-relaxed">
              Every decision is evaluated across a 3×3 grid, with each cell holding three valences:
            </p>

            {/* Matrix visualization */}
            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-sm">
                <thead>
                  <tr>
                    <th className="p-4 text-left font-display text-foreground bg-card border border-border"></th>
                    <th className="p-4 text-center font-display font-semibold text-foreground bg-card border border-border">Self</th>
                    <th className="p-4 text-center font-display font-semibold text-foreground bg-card border border-border">Other</th>
                    <th className="p-4 text-center font-display font-semibold text-foreground bg-card border border-border">System</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    { row: "Governance", cells: ["Authority & autonomy", "Consent & representation", "Institutional stability"] },
                    { row: "Economy", cells: ["Resource access", "Fair exchange", "Market health"] },
                    { row: "Culture", cells: ["Identity & expression", "Recognition & belonging", "Narrative coherence"] },
                  ].map((r) => (
                    <tr key={r.row}>
                      <td className="p-4 font-display font-semibold text-foreground bg-card border border-border">{r.row}</td>
                      {r.cells.map((cell, i) => (
                        <td key={i} className="p-4 text-muted-foreground border border-border text-center">{cell}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <p className="text-sm text-muted-foreground mt-4 italic">
              Each cell is evaluated at three valences: [-1] how this could cause harm, [0] what remains genuinely uncertain, [+1] what concrete benefit is produced.
            </p>
          </div>
        </FadeIn>

        {/* Three Valences */}
        <FadeIn delay={0.2}>
          <h2 className="font-display text-2xl font-bold text-foreground mb-6">
            The Three Valences
          </h2>
          <div className="space-y-6 mb-12">
            {[
              {
                label: "[-1] Harm",
                desc: "What damage could this cause? To whom? By what mechanism? Harm must remain visible in the analysis — burying it produces systems that export costs to those with the least power to object.",
                color: "border-destructive",
              },
              {
                label: "[0] Uncertainty",
                desc: "What do we genuinely not know? Uncertainty is not a failure state. It's information. A framework that eliminates uncertainty is modeling confidence, not reality. The [0] valence is an apparatus — it measures what hasn't been measured.",
                color: "border-highlight",
              },
              {
                label: "[+1] Benefit",
                desc: "What concrete positive outcome does this produce? Not aspirational — measurable. The benefit must be specific enough to verify and falsifiable enough to test.",
                color: "border-primary",
              },
            ].map((v) => (
              <div key={v.label} className={`border-l-4 ${v.color} pl-6 py-2`}>
                <h3 className="font-display text-lg font-semibold text-foreground mb-1">{v.label}</h3>
                <p className="text-muted-foreground leading-relaxed">{v.desc}</p>
              </div>
            ))}
          </div>
        </FadeIn>

        {/* Start here routing */}
        <FadeIn delay={0.25}>
          <div className="bg-card rounded-lg border border-border p-8 md:p-10">
            <h2 className="font-display text-2xl font-bold text-foreground mb-6">
              Where to go from here
            </h2>
            <div className="space-y-4">
              {[
                { label: "I want to understand the ideas", to: "/research", desc: "Read the formal specifications and research papers." },
                { label: "I want to apply something", to: "#", desc: "Tools and templates for practitioners. Coming soon." },
                { label: "I want the accessible version", to: "#", desc: "Books and articles that explain the frameworks in plain language." },
              ].map((route) => (
                <Link
                  key={route.label}
                  to={route.to}
                  className="flex items-center justify-between gap-4 group p-4 -mx-4 rounded hover:bg-accent-glow transition-colors"
                >
                  <div>
                    <p className="font-body font-semibold text-foreground group-hover:text-primary transition-colors">{route.label}</p>
                    <p className="text-sm text-muted-foreground">{route.desc}</p>
                  </div>
                  <ArrowRight size={18} className="text-muted-foreground group-hover:text-primary transition-colors shrink-0" />
                </Link>
              ))}
            </div>
          </div>
        </FadeIn>
      </div>
    </article>
  </SiteLayout>
);

export default Framework;
