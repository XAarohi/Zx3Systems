import { FileText, ExternalLink } from "lucide-react";
import SiteLayout from "@/components/SiteLayout";
import FadeIn from "@/components/FadeIn";

const publications = [
  {
    title: "Zx3 Core Specification v1.0",
    type: "Core Standard",
    date: "2025-11-25",
    status: "Published" as const,
    desc: "Defines the minimal invariant concepts for the Zx3 multi-valence framework. The foundational document from which all other specifications derive.",
    license: "CC-BY-SA 4.0",
    tags: ["specification", "researcher"],
  },
  {
    title: "PC-Ext v0.2 — Predictive Coding Extension",
    type: "Research Paper",
    date: "2026-01",
    status: "Preprint" as const,
    desc: "Formal correction to Friston's free energy principle, extending predictive coding to account for cooperative surplus as a measurable thermodynamic phenomenon.",
    license: "CC-BY-SA 4.0",
    tags: ["AI safety", "researcher"],
  },
  {
    title: "Rendering Layer v0.2",
    type: "Technical Specification",
    date: "2026-02",
    status: "Preprint" as const,
    desc: "Processing stack foundation defining τ-event, μ-event, and μᴿ-event vocabulary for the consciousness theory arc.",
    license: "CC-BY-SA 4.0",
    tags: ["consciousness", "specification"],
  },
];

const statusColors: Record<string, string> = {
  Published: "bg-primary/10 text-primary",
  Preprint: "bg-highlight/15 text-highlight-foreground",
  "In Review": "bg-muted text-muted-foreground",
};

const Research = () => (
  <SiteLayout>
    <section className="pt-16 pb-20 md:pt-24 md:pb-32">
      <div className="wide-container">
        <FadeIn>
          <p className="text-sm font-body font-semibold uppercase tracking-widest text-primary mb-3">Research</p>
          <h1 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold leading-tight text-foreground mb-4">
            Publications & Specifications
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mb-12">
            Formal specifications, research papers, and technical documents. All work is timestamped and published under open licenses.
          </p>
        </FadeIn>

        <div className="space-y-6">
          {publications.map((pub, i) => (
            <FadeIn key={pub.title} delay={0.05 * (i + 1)}>
              <div className="border border-border rounded-lg p-6 md:p-8 hover:border-primary/30 transition-colors group">
                <div className="flex flex-wrap items-center gap-3 mb-3">
                  <span className={`text-xs font-mono px-2.5 py-1 rounded-full ${statusColors[pub.status]}`}>
                    {pub.status}
                  </span>
                  <span className="text-xs font-mono text-muted-foreground">{pub.type}</span>
                  <span className="text-xs font-mono text-muted-foreground">·</span>
                  <span className="text-xs font-mono text-muted-foreground">{pub.date}</span>
                </div>
                <h2 className="font-display text-xl md:text-2xl font-semibold text-foreground group-hover:text-primary transition-colors mb-2">
                  {pub.title}
                </h2>
                <p className="text-muted-foreground leading-relaxed mb-4">{pub.desc}</p>
                <div className="flex flex-wrap items-center gap-4">
                  <button className="inline-flex items-center gap-2 text-sm font-semibold text-primary hover:underline underline-offset-4">
                    <FileText size={15} />
                    Download PDF
                  </button>
                  <button className="inline-flex items-center gap-2 text-sm font-semibold text-muted-foreground hover:text-primary transition-colors">
                    <ExternalLink size={15} />
                    Accessible version
                  </button>
                </div>
                <div className="flex gap-2 mt-4">
                  {pub.tags.map((tag) => (
                    <span key={tag} className="text-xs font-mono px-2 py-0.5 bg-muted text-muted-foreground rounded">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </FadeIn>
          ))}
        </div>
      </div>
    </section>
  </SiteLayout>
);

export default Research;
