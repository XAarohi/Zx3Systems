import { Link } from "react-router-dom";

const SiteFooter = () => (
  <footer className="border-t border-border mt-24">
    <div className="wide-container py-12 flex flex-col md:flex-row justify-between gap-8">
      <div>
        <p className="font-display text-lg font-semibold text-foreground">Zx3 Systems</p>
        <p className="text-sm text-muted-foreground mt-1">
          Independent research for ethical governance, AI safety, and human thriving.
        </p>
      </div>
      <div className="flex flex-col gap-2 text-sm">
        <Link to="/framework" className="text-muted-foreground hover:text-primary transition-colors">Framework</Link>
        <Link to="/research" className="text-muted-foreground hover:text-primary transition-colors">Research</Link>
        <Link to="/about" className="text-muted-foreground hover:text-primary transition-colors">About</Link>
      </div>
      <div className="flex flex-col gap-2 text-sm text-muted-foreground">
        <a href="mailto:XssandraAarohi@proton.me" className="hover:text-primary transition-colors">
          XssandraAarohi@proton.me
        </a>
        <p>Content licensed CC-BY-SA 4.0</p>
      </div>
    </div>
  </footer>
);

export default SiteFooter;
